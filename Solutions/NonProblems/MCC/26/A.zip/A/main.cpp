#include <algorithm>
#include <iostream>
#include <queue>
#include <string>
#include <utility>
#include <vector>
using namespace std;

struct Tradesman {
    int start;
    int dest;
    int appear;
};

struct Tick {
    vector<string> actions;
    vector<pair<int, int>> moves; // train_id, next_city
};

static vector<int> shortest_path(int src, int dst, const vector<vector<int>>& adj) {
    if (src == dst) return {src};

    int n = (int)adj.size() - 1;
    vector<int> parent(n + 1, -1);
    queue<int> q;
    parent[src] = src;
    q.push(src);

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        if (u == dst) break;
        for (int v : adj[u]) {
            if (parent[v] != -1) continue;
            parent[v] = u;
            q.push(v);
        }
    }

    // The statement guarantees the graph is connected, so this should exist.
    vector<int> path;
    for (int cur = dst; cur != src; cur = parent[cur]) {
        path.push_back(cur);
    }
    path.push_back(src);
    reverse(path.begin(), path.end());
    return path;
}

static void add_idle_ticks(vector<Tick>& plan, int& current_tick, int target_tick) {
    while (current_tick < target_tick) {
        plan.push_back(Tick{});
        current_tick++;
    }
}

static void move_train_along_path(
    vector<Tick>& plan,
    int& current_tick,
    int train_id,
    int& train_pos,
    const vector<int>& path
) {
    for (int i = 1; i < (int)path.size(); i++) {
        Tick tick;
        tick.moves.push_back({train_id, path[i]});
        plan.push_back(tick);
        train_pos = path[i];
        current_tick++;
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int V, E;
    if (!(cin >> V >> E)) return 0;

    vector<vector<int>> adj(V + 1);
    for (int i = 0; i < E; i++) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    for (int i = 1; i <= V; i++) {
        sort(adj[i].begin(), adj[i].end());
    }

    int T;
    cin >> T;
    vector<int> train_start(T + 1);
    for (int i = 1; i <= T; i++) cin >> train_start[i];

    int C;
    cin >> C;

    int N;
    cin >> N;
    vector<Tradesman> people(N + 1);
    for (int i = 1; i <= N; i++) {
        cin >> people[i].start >> people[i].dest >> people[i].appear;
    }

    // Starter baseline:
    // Use only train 1. It carries one tradesman at a time, so capacity and
    // collision constraints are automatically satisfied.
    const int train_id = 1;
    int train_pos = train_start[train_id];
    int current_tick = 1;
    vector<Tick> plan;

    for (int id = 1; id <= N; id++) {
        const Tradesman& p = people[id];

        vector<int> to_start = shortest_path(train_pos, p.start, adj);
        move_train_along_path(plan, current_tick, train_id, train_pos, to_start);

        add_idle_ticks(plan, current_tick, p.appear);

        vector<int> to_dest = shortest_path(train_pos, p.dest, adj);
        if ((int)to_dest.size() <= 1) {
            // This should not happen because start != dest in the input.
            continue;
        }

        Tick first_ride_tick;
        first_ride_tick.actions.push_back(
            "pick " + to_string(train_id) + " " + to_string(id)
        );
        first_ride_tick.moves.push_back({train_id, to_dest[1]});
        plan.push_back(first_ride_tick);
        train_pos = to_dest[1];
        current_tick++;

        for (int i = 2; i < (int)to_dest.size(); i++) {
            Tick tick;
            tick.moves.push_back({train_id, to_dest[i]});
            plan.push_back(tick);
            train_pos = to_dest[i];
            current_tick++;
        }

        Tick drop_tick;
        drop_tick.actions.push_back(
            "drop " + to_string(train_id) + " " + to_string(id)
        );
        plan.push_back(drop_tick);
        current_tick++;
    }

    cout << plan.size() << '\n';
    for (const Tick& tick : plan) {
        cout << tick.actions.size() << '\n';
        for (const string& action : tick.actions) {
            cout << action << '\n';
        }
        cout << tick.moves.size() << '\n';
        for (auto [train, city] : tick.moves) {
            cout << train << ' ' << city << '\n';
        }
    }

    return 0;
}
