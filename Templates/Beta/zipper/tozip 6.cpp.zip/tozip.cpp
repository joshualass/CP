#include <iostream>
#include <vector>

using namespace std;

const int MOD = 1000000007;

long long power(long long base, long long exp) {
    long long res = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp % 2 == 1) res = (res * base) % MOD;
        base = (base * base) % MOD;
        exp /= 2;
    }
    return res;
}

int main() {
    int n, k;
    long long m;
    cin >> n >> m >> k;

    vector<vector<long long>> C(n + 1, vector<long long>(n + 1));
    for (int i = 0; i <= n; ++i) {
        for (int j = 0; j <= i; ++j) {
            if (j == 0 || j == i) C[i][j] = 1;
            else C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % MOD;
        }
    }

    vector<long long> dp(k + 1, 0);
    vector<long long> prev_dp(k + 1, 0);
    prev_dp[0] = 1;

    for (int i = 0; i < n; ++i) {
        long long cnt = m / n + (i < m % n);
        vector<long long> powers(n + 1);
        for(int j = 0; j <= n; ++j) {
            powers[j] = power(C[n][j], cnt);
        }

        fill(dp.begin(), dp.end(), 0);

        for (int sum = 0; sum <= k; ++sum) {
            for (int j = 0; j <= n; ++j) {
                int new_sum = sum + j;
                if (i == n - 1 && new_sum != k) continue;
                if (new_sum <= k) {
                    dp[new_sum] = (dp[new_sum] + (prev_dp[sum] * powers[j]) % MOD) % MOD;
                }
            }
        }
        prev_dp = dp;
    }

    cout << dp[k] << endl;

    return 0;
}