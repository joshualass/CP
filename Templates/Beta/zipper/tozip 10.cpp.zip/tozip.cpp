#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n, m, h;
    cin >> n >> m >> h;

    vector<int> u(n);
    for (int i = 0; i < n; ++i) {
        cin >> u[i];
    }

    vector<vector<int>> adj(n);
    for (int i = 0; i < m; ++i) {
        int c1, c2;
        cin >> c1 >> c2;
        --c1; --c2;
        if ((u[c1] + 1) % h == u[c2]) {
            adj[c1].push_back(c2);
        }
        if ((u[c2] + 1) % h == u[c1]) {
            adj[c2].push_back(c1);
        }
    }

    if (m == 0) {
        cout << 1 << endl;
        cout << 1 << endl;
        return 0;
    }

    int min_shift = n + 1;
    vector<int> min_shift_nodes;

    for (int i = 0; i < n; ++i) {
        vector<int> shift_nodes = {i};
        vector<bool> shifted(n, false);
        shifted[i] = true;
        vector<int> q = {i};
        int head = 0;

        while (head < q.size()) {
            int u = q[head++];
            for (int v : adj[u]) {
                if (!shifted[v]) {
                    shifted[v] = true;
                    shift_nodes.push_back(v);
                    q.push_back(v);
                }
            }
        }
        
        bool valid_shift = true;
        for (int node : shift_nodes) {
            for (int neighbor : adj[node]) {
                if (!shifted[neighbor]) {
                   valid_shift = false;
                   break; 
                }
            }
             if (!valid_shift) break;
        }

        if (valid_shift) {
            if (shift_nodes.size() < min_shift) {
                min_shift = shift_nodes.size();
                min_shift_nodes = shift_nodes;
            }
        }

    }
    cout << min_shift << endl;
    for (int i = 0; i < min_shift_nodes.size(); i++) {
        cout << min_shift_nodes[i] + 1 << (i == min_shift_nodes.size() - 1 ? "" : " ");
    }
    cout << endl;


    return 0;
}