# MCC 26 Starter

This is a deliberately simple baseline for the train-routing optimization task.

## What It Does

- Parses one test case from standard input.
- Uses train `1` only.
- Serves tradesmen in input order.
- Moves the train to the tradesman's starting city, waits until their appearance time, picks them up, moves them to their destination, and drops them off.

Because only one train ever moves, this starter avoids rail collisions by construction. Because it carries one tradesman at a time, it also respects train capacity as long as `C >= 1`.

This is not intended to score well. It is meant to produce understandable, valid output for small and medium cases and give you clean hooks for improving the strategy.

## Build And Run One Case

```bash
g++ -std=c++17 -O2 -pipe -Wall -Wextra main.cpp -o solver
./solver < 01.in > 01.out
```

## Generate And Keep Best Outputs

Put the official tests in `tests/01`, `tests/02`, ..., `tests/08`, then run:

```bash
python3 run_all.py
```

The script compiles `main.cpp`, runs each test, scores the candidate output,
and only replaces an existing saved output when the candidate has a lower raw
score. It writes:

- `candidates/01.out`, `candidates/02.out`, ...
- `outputs/01.out`, `outputs/02.out`, ...
- `outputs.zip`

You can still pass a different input directory if needed:

```bash
python3 run_all.py path/to/other/tests
```

To overwrite saved outputs regardless of score:

```bash
python3 run_all.py --force
```

## Easy Next Improvements

- Use multiple trains, but reserve each edge per tick to avoid collisions.
- Assign each tradesman to the nearest available train.
- Cache shortest paths from repeated source cities.
- Batch multiple tradesmen on one train when their routes overlap and capacity allows.
