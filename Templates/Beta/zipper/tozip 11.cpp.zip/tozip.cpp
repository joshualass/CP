#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        vector<string> board(n);
        for (int i = 0; i < n; i++) {
            cin >> board[i];
        }

        for (int d = 0; d < 10; d++) {
            long long max_area = 0;
            vector<pair<int, int>> cells;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (board[i][j] - '0' == d) {
                        cells.push_back({i, j});
                    }
                }
            }

            for (int i = 0; i < cells.size(); i++) {
                for (int j = i + 1; j < cells.size(); j++) {
                    max_area = max(max_area, (long long)abs(cells[i].first - cells[j].first) * abs(cells[i].second - cells[j].second));
                }
            }

            for (int i = 0; i < n; i++){
                for (int j = 0; j < n; j++){
                    int min_r = n, max_r = -1, min_c = n, max_c = -1;
                    for(auto cell : cells){
                        min_r = min(min_r, cell.first);
                        max_r = max(max_r, cell.first);
                        min_c = min(min_c, cell.second);
                        max_c = max(max_c, cell.second);
                    }

                    if (cells.empty()) continue;

                    max_area = max(max_area, (long long)(max_r - min_r) * max(abs(j- min_c), abs(j - max_c)));
                   max_area = max(max_area, (long long)(max_c - min_c) * max(abs(i- min_r), abs(i - max_r)));
                }
            }

            cout << max_area << " ";
        }
        cout << endl;
    }
    return 0;
}