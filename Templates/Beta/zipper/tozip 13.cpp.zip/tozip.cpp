#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n, k;
    cin >> n >> k;

    vector<int> a(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }

    sort(a.begin(), a.end());

    vector<vector<vector<long long>>> dp(n + 1, vector<vector<long long>>(n + 1, vector<long long>(k + 1, 0)));
    dp[0][0][0] = 1;

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j <= i; ++j) {
            for (int l = 0; l <= k; ++l) {
                if (dp[i][j][l] == 0) continue;

                int diff = (i > 0) ? (a[i] - a[i - 1]) * j : 0;

                // Add to existing set or create a singleton set
                if (l + diff <= k) {
                    dp[i + 1][j][l + diff] = (dp[i + 1][j][l + diff] + dp[i][j][l] * (j + 1)) % 1000000007;
                }

                // Create a new set
                if (l + diff <= k) {
                    dp[i + 1][j + 1][l + diff] = (dp[i + 1][j + 1][l + diff] + dp[i][j][l]) % 1000000007;
                }

                // Close a set
                if (j > 0 && l + diff <= k) {
                    dp[i + 1][j - 1][l + diff] = (dp[i + 1][j - 1][l + diff] + dp[i][j][l] * j) % 1000000007;
                }
            }
        }
    }

    long long ans = 0;
    for (int l = 0; l <= k; ++l) {
        ans = (ans + dp[n][0][l]) % 1000000007; // Only consider cases where all groups are closed (j=0)
    }

    cout << ans << endl;

    return 0;
}