#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

int main() {
    int n, x;
    cin >> n >> x;

    vector<int> a(n + 1);
    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
    }

    vector<int> next(n + 1);
    for (int i = 1; i <= n; ++i) {
        next[i] = a[i];
    }

    int val = 0;
    int pos = x;
    while (pos != 0) {
        val++;
        pos = next[pos];
    }

    vector<int> lengths;
    vector<bool> pointed_to(n + 1, false);
    for (int i = 1; i <= n; ++i) {
        if (next[i] != 0) {
            pointed_to[next[i]] = true;
        }
    }

    vector<int> starts;
    for (int i = 1; i <= n; ++i) {
        if (!pointed_to[i]) {
            starts.push_back(i);
        }
    }

    for (int start : starts) {
        int len = 0;
        int curr = start;
        bool in_x_chain = false;

        while (curr != 0) {
            if (curr == x) {
                in_x_chain = true;
            }
            len++;
            curr = next[curr];
        }
        if (!in_x_chain) {
            lengths.push_back(len);
        }
    }

    vector<bool> dp(n + 1, false);
    dp[0] = true;

    for (int len : lengths) {
        for (int i = n; i >= len; --i) {
            if (dp[i - len]) {
                dp[i] = true;
            }
        }
    }

    vector<int> ans;
    for (int i = 0; i <= n; ++i) {
        if (dp[i]) {
            ans.push_back(i + val);
        }
    }

    sort(ans.begin(), ans.end());
    for (int pos : ans) {
        cout << pos << endl;
    }

    return 0;
}